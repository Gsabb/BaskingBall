
# BASKING BALL

I made this while bored in class so that you could play this while bored in class. A simple arcade retro-style 2D game.

## 🚀 About Me
I'm an IT student completing my bachelor's degree in computer science at the Université de Montréal. 


## Free download

```javascript
- Download the .zip file
- Extract all
- Run BaskingBall.exe
- Make it rain
```


## 🔗 Links
[![github](https://img.shields.io/badge/github-000?style=for-the-badge&logo=ko-fi&logoColor=white)](https://github.com/Gsabb/)
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/guillaume-sabourin-bba09b318/)

